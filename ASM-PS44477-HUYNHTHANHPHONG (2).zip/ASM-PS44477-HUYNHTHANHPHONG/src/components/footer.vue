<template>
  <footer class="bg-white border-top py-4 text-center">
    <div class="container mb-3">
      <p class="text-muted small">
        © 2025 PhongHuynh. Bảo lưu mọi quyền.
      </p>
    </div>
  </footer>
</template>



<template>
  <footer class="bg-white border-top py-4 text-center">
    <div class="container">
      <div class="d-flex flex-wrap justify-content-center gap-4 mb-3">
        <a href="#" class="text-muted">Chính sách bảo mật</a>
        <a href="#" class="text-muted">Điều khoản dịch vụ</a>
        <a href="#" class="text-muted">Liên hệ</a>
      </div>

      <p class="text-muted small">
        © 2025 PhongHuynh. Bảo lưu mọi quyền.
      </p>
    </div>
  </footer>
</template>



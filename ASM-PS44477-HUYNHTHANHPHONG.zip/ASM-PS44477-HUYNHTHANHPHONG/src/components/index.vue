<template>
<div class="row row-cols-1 row-cols-md-3 g-4">
  <div class="col">
    <div class="card h-100">
      <img src="https://cdn-i.vtcnews.vn/resize/th/upload/2026/01/19/base64-17239699328551748199622-17152344.jpeg" class="card-img-top " alt="...">
      <div class="card-body">
        <h5 class="card-title">Gần 100 trường đại học công bố lịch nghỉ Tết Bính Ngọ: ‘Kỷ lục’ nghỉ tới 43 ngày</h5>
        <p class="card-text">Theo cập nhật mới nhất, đến thời điểm hiện tại đã có gần 100 trường đại học công bố hoặc thông tin dự kiến lịch nghỉ Tết Nguyên đán năm 2026 cho sinh viên. </p>
        <a href="/postDetail" class="btn btn-primary">xem thêm</a>
      </div>
      <div class="card-footer">
        <small class="text-body-secondary">Last updated 3 mins ago</small>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="https://photo-baomoi.bmcdn.me/w700_r1/2026_01_19_15_54291337/2e66b4ad9ee577bb2ef4.jpg.avif" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Bão Nokaen sắp đổi hướng, có ảnh hưởng tới nước ta?</h5>
        <p class="card-text">Theo cập nhật mới nhất, đến thời điểm hiện tại đã có gần 100 trường đại học công bố hoặc thông tin dự kiến lịch nghỉ Tết Nguyên đán năm 2026 cho sinh viên. </p>
        <a href="#" class="btn btn-primary">xem thêm</a>
      </div>
      <div class="card-footer">
        <small class="text-body-secondary">Last updated 3 mins ago</small>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="https://photo-baomoi.bmcdn.me/w250_r3x2/2026_01_19_23_54291876/1899612b4b63a23dfb72.jpg.avif" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Galaxy S26 Ultra: 4 màu 'chốt hạ' cực bắt mắt</h5>
        <p class="card-text">Không chỉ tiết lộ đủ bốn màu chính của Galaxy S26 Ultra, nguồn tin này còn trùng khớp hoàn toàn với báo cáo trước đó,</p>
        <a href="#" class="btn btn-primary">xem thêm</a>
      </div>
      <div class="card-footer">
        <small class="text-body-secondary">Last updated 3 mins ago</small>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="https://cdn-i.vtcnews.vn/resize/th/upload/2026/01/19/base64-17239699328551748199622-17152344.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Gần 100 trường đại học công bố lịch nghỉ Tết Bính Ngọ: ‘Kỷ lục’ nghỉ tới 43 ngày</h5>
        <p class="card-text">Theo cập nhật mới nhất, đến thời điểm hiện tại đã có gần 100 trường đại học công bố hoặc thông tin dự kiến lịch nghỉ Tết Nguyên đán năm 2026 cho sinh viên. </p>
        <a href="#" class="btn btn-primary">xem thêm</a>
      </div>
      <div class="card-footer">
        <small class="text-body-secondary">Last updated 3 mins ago</small>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="https://photo-baomoi.bmcdn.me/w700_r1/2026_01_19_15_54291337/2e66b4ad9ee577bb2ef4.jpg.avif" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Bão Nokaen sắp đổi hướng, có ảnh hưởng tới nước ta?</h5>
        <p class="card-text">Theo cập nhật mới nhất, đến thời điểm hiện tại đã có gần 100 trường đại học công bố hoặc thông tin dự kiến lịch nghỉ Tết Nguyên đán năm 2026 cho sinh viên. </p>
        <a href="#" class="btn btn-primary">xem thêm</a>
      </div>
      <div class="card-footer">
        <small class="text-body-secondary">Last updated 3 mins ago</small>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card h-100">
      <img src="https://photo-baomoi.bmcdn.me/w250_r3x2/2026_01_19_23_54291876/1899612b4b63a23dfb72.jpg.avif" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Galaxy S26 Ultra: 4 màu 'chốt hạ' cực bắt mắt</h5>
        <p class="card-text">Không chỉ tiết lộ đủ bốn màu chính của Galaxy S26 Ultra, nguồn tin này còn trùng khớp hoàn toàn với báo cáo trước đó,</p>
        <a href="#" class="btn btn-primary">xem thêm</a>
      </div>
      <div class="card-footer">
        <small class="text-body-secondary">Last updated 3 mins ago</small>
      </div>
    </div>
  </div>
</div>
</template>


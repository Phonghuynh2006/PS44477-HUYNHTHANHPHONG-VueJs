<template>


  <!-- MAIN CONTENT -->
    <div class="container">

      <!-- BACK BUTTON -->
      <div class="mb-4">
        <router-link to="/" class="btn btn-outline-secondary d-inline-flex align-items-center gap-2">
          ← Quay lại Trang chủ
        </router-link>
      </div>

      <!-- TITLE + INFO -->
      <div class="text-center mb-4">
        <h1 class="fw-bold display-5">Bộ Quốc phòng yêu cầu các đơn vị tập trung ứng phó mưa lũ tại khu vực Trung Bộ</h1>

        <div class="d-flex justify-content-center gap-3 mt-3 text-secondary">
          <span>Tác giả: ngu</span>
          <span>|</span>
          <span>Ngày đăng: 19 tháng 11, 2025</span>
        </div>
      </div>

      <!-- POST IMAGE -->
      <div class="rounded overflow-hidden mb-5 shadow-sm">
        <img
          src="https://photo-baomoi.bmcdn.me/w700_r16x9/2025_11_21_14_53820038/f16588cc2585ccdb9594.jpg.avif"
          class="w-100"
          alt="Post Image"
        >
      </div>

      <!-- POST CONTENT -->
      <div class="mb-5" style="max-width: 900px; margin: auto;">

        <p class="fs-5 text-dark">
Ngày 21/11, Bộ Quốc phòng ban hành công điện hỏa tốc số 7483/CĐ-BQP về việc tập trung ứng phó và khắc phục hậu quả mưa lũ đặc biệt lớn tại khu vực Trung Bộ gửi: Bộ Tổng Tham mưu Quân đội nhân dân Việt Nam, Tổng cục Chính trị Quân đội nhân dân Việt Nam; Tổng cục: Hậu cần–Kỹ thuật; các Quân khu: 4, 5, 7; Quân đoàn 34; Quân chủng: Phòng không–Không quân, Hải quân; Bộ đội Biên phòng, Cảnh sát biển Việt Nam; Bộ Tư lệnh Pháo binh-Tên lửa; Binh chủng: Tăng Thiết giáp, Đặc công, Công binh, Hóa học, Thông tin liên lạc; Binh đoàn: 12, 15, 18; Học viện Lục quân; Tập đoàn Công nghiệp-Viễn thông Quân đội.
        </p>
<p class="fs-5 text-dark">
Thực hiện Công điện số 225/CĐ-TTg ngày 20/11/2025 của Thủ tướng Chính phủ; ý kiến chỉ đạo của đồng chí Đại tướng Phan Văn Giang, Ủy viên Bộ Chính trị, Bộ trưởng Quốc phòng về việc khắc phục hậu quả mưa lũ đặc biệt lớn tại khu vực Trung Bộ; để nhanh chóng ổn định đời sống nhân dân và giảm thiểu thiệt hại về người, tài sản của Nhà nước và nhân dân; Bộ Quốc phòng yêu cầu các cơ quan, đơn vị:
    </p>
      </div>

      <!-- COMMENTS -->
      <div class="border-top pt-5">
        <h2 class="fw-bold mb-4">Bình luận (2)</h2>

        <!-- COMMENT ITEM -->
        <div class="d-flex gap-3 mb-4">
          <div class="bg-secondary bg-opacity-25 rounded-circle d-flex align-items-center justify-content-center"
               style="width: 48px; height: 48px;">
            <span class="text-secondary fs-4">👤</span>
          </div>

          <div>
            <p class="fw-bold mb-1">phong</p>
            <p class="text-muted small mb-2">2 ngày trước</p>
            <p> Bài viết tuyệt vời! Rất nhiều thông tin hữu ích. </p>
          </div>
        </div>

        <!-- COMMENT ITEM -->
        <div class="d-flex gap-3 mb-4">
          <div class="bg-secondary bg-opacity-25 rounded-circle d-flex align-items-center justify-content-center"
               style="width: 48px; height: 48px;">
            <span class="text-secondary fs-4">👤</span>
          </div>

          <div>
            <p class="fw-bold mb-1">phong1</p>
            <p class="text-muted small mb-2">1 ngày trước</p>
            <p> Hướng dẫn rất rõ ràng và dễ hiểu. </p>
          </div>
        </div>

        <!-- COMMENT FORM -->
        <h3 class="fw-bold mt-5 mb-3">Để lại bình luận</h3>

        <textarea
          class="form-control mb-3"
          rows="4"
          placeholder="Viết bình luận của bạn ở đây..."
        ></textarea>

        <button class="btn btn-primary px-4 py-2 fw-bold">
          Gửi bình luận
        </button>
      </div>

    </div>




</template>



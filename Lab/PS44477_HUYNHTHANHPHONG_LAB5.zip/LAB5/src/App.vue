<script setup>
import { ref } from 'vue'
import Bai1 from './components/bai1.vue'
import Bai2 from './components/bai2.vue'
import Bai3 from './components/bai3.vue'
import CreatePost from './components/CreatePost.vue'
import PostList from './components/PostList.vue'

const posts = ref([])

function addPost(post) {
  posts.value.push(post)
}
</script>

<template>

<Bai1 />
<Bai2 />
<Bai3 />
<h1>ung dung blog</h1>
<CreatePost @add-post="addPost" />
<PostList :posts="posts" />

</template>



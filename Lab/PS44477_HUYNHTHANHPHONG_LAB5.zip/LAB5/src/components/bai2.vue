<template>
  <div>
    <input v-model="nhapdulieu" placeholder="Nhập dữ liệu nhanh lên" />
    <p>Giá trị bạn nhập: {{ nhapdulieu }}</p>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const nhapdulieu = ref('phonghuynh')
</script>























































































<!-- _____  _    _  ____  _   _  _____ _    _ _    ___     ___   _ _    _ 
 |  __ \| |  | |/ __ \| \ | |/ ____| |  | | |  | \ \   / / \ | | |  | |
 | |__) | |__| | |  | |  \| | |  __| |__| | |  | |\ \_/ /|  \| | |__| |
 |  ___/|  __  | |  | | . ` | | |_ |  __  | |  | | \   / | . ` |  __  |
 | |    | |  | | |__| | |\  | |__| | |  | | |__| |  | |  | |\  | |  | |
 |_|    |_|  |_|\____/|_| \_|\_____|_|  |_|\____/   |_|  |_| \_|_|  |_|
                                                                        -->
                                                                       
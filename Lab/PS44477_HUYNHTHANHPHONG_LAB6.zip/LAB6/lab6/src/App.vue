<script setup>
import Bai1 from './components/bai1.vue';
import Bai2 from './components/bai2.vue';
import Bai3 from './components/bai3.vue';
import bai4 from './components/bai4.vue';
</script>

<template>

    <Bai1 />

    <Bai2 />
    <Bai3 />
    <bai4 />
</template>

<style scoped>

</style>

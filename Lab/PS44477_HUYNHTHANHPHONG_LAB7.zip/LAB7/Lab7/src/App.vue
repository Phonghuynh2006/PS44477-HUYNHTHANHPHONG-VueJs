<script setup>
import Bai1 from './components/Bai1.vue'
import Bai2 from './components/Bai2.vue'
import Bai3 from './components/Bai3.vue'
import Bai4 from './components/Bai4.vue'

</script>

<template>

    <Bai1 />

    <!-- <hr />
    <Bai2 /> -->

    <!-- <hr />
    <Bai3 /> -->

    <!-- <hr />
    <Bai4 /> -->
</template>

<style scoped>

</style>
